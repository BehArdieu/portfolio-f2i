-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : jeu. 22 juil. 2021 à 09:35
-- Version du serveur :  5.7.24
-- Version de PHP : 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cody_b_tontine`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `tarif` int(11) NOT NULL,
  `solde` int(11) NOT NULL,
  `reste_a_ramasser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `id_client`, `nom`, `tarif`, `solde`, `reste_a_ramasser`) VALUES
(1, 1, 'Beh Ardieu', 300, 1600, 2),
(11, 12, 'Massoud', 100, 3000, 1),
(23, 1227, 'Gydson', 500, 0, 2),
(37, 120054, 'Emmanuel', 300, 0, 2),
(39, 2, 'Comlan', 200, 0, 1),
(40, 554, 'Raoul', 200, 0, 2),
(42, 4, 'Platon', 400, 0, 3),
(43, 5, 'Socrate', 1000, 0, 8),
(44, 13, 'Isaac', 500, 0, 1),
(45, 14, 'Atavi', 200, 0, 2),
(46, 555, 'Junior', 100, 0, 1),
(47, 145, 'Chance', 200, 0, 2),
(48, 155, 'Onésime', 100, 0, 1),
(49, 77, 'Fabrice', 100, 0, 2),
(50, 147, 'Sunsay', 200, 0, 2),
(51, 22, 'Faure', 100, 10000, 1);

-- --------------------------------------------------------

--
-- Structure de la table `dates`
--

CREATE TABLE `dates` (
  `id` int(255) NOT NULL,
  `type_date` varchar(255) NOT NULL,
  `valeur` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `dates`
--

INSERT INTO `dates` (`id`, `type_date`, `valeur`) VALUES
(1, 'date_debut', 'mercredi-14-oct.-2020'),
(2, 'date_fin', 'mardi-06-avr.-2021'),
(3, 'date_last_payement', '');

-- --------------------------------------------------------

--
-- Structure de la table `payements`
--

CREATE TABLE `payements` (
  `id` int(11) NOT NULL,
  `id_payement` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `somme` int(255) DEFAULT NULL,
  `date_payement` varchar(255) NOT NULL,
  `quinzaine` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `payements`
--

INSERT INTO `payements` (`id`, `id_payement`, `id_client`, `somme`, `date_payement`, `quinzaine`) VALUES
(1, 1, 12, 200, 'jeudi-03-sept.-2020', 'N° 1'),
(2, 2, 120054, 300, 'jeudi-03-sept.-2020', 'N° 1'),
(3, 3, 1, 200, 'jeudi-03-sept.-2020', 'N° 1'),
(4, 5, 1227, 200, 'jeudi-03-sept.-2020', 'N° 1'),
(5, 4, 12, 200, 'jeudi-03-sept.-2020', 'N° 1'),
(6, 6, 12, 200, 'jeudi-03-sept.-2020', 'N° 3'),
(7, 7, 120054, 400, 'jeudi-03-sept.-2020', 'N° 1'),
(8, 41, 5, 2000, 'jeudi-03-sept.-2020', 'N° 5'),
(9, 8, 12, 200, 'vendredi-04-sept.-2020', 'N° 2'),
(10, 10, 13, 500, 'vendredi-04-sept.-2020', 'N° 1'),
(11, 444, 12, 200, 'vendredi-04-sept.-2020', 'N° 1'),
(12, 44444, 12, 200, 'vendredi-04-sept.-2020', 'N° 5'),
(13, 30, 555, 100, 'samedi-05-sept.-2020', 'N° 1'),
(14, 40, 12, 200, 'samedi-05-sept.-2020', 'N° 4'),
(15, 411, 554, 200, 'samedi-05-sept.-2020', 'N° 20'),
(16, 63, 145, 200, 'dimanche-06-sept.-2020', 'N° 1'),
(17, 64, 145, 300, 'dimanche-06-sept.-2020', 'N° 2'),
(18, 65, 145, 1000, 'dimanche-06-sept.-2020', 'N° 20'),
(19, 53, 155, 500, 'dimanche-06-sept.-2020', 'N° 1'),
(20, 85, 155, 200, 'dimanche-06-sept.-2020', 'N° 20'),
(21, 42, 12, 200, 'dimanche-20-sept.-2020', 'N° 7'),
(22, 4444, 77, 100, 'lundi-12-oct.-2020', 'N° 1'),
(28, 1212, 4, 400, 'mardi-13-oct.-2020', 'N° 1'),
(31, 101, 12, 100, 'mardi-13-oct.-2020', 'N° 1'),
(36, 100, 12, 100, 'mardi-13-oct.-2020', 'N° 1'),
(37, 102, 1, 100, 'mardi-13-oct.-2020', 'N° 1'),
(38, 104, 1, 100, 'mardi-13-oct.-2020', 'N° 1'),
(39, 753, 1, 200, 'mardi-13-oct.-2020', 'N° 1'),
(40, 200, 1, 200, 'mardi-13-oct.-2020', 'N° 1'),
(41, 741, 1, 300, 'mardi-13-oct.-2020', 'N° 1'),
(42, 258, 1227, 300, 'mardi-13-oct.-2020', 'N° 1'),
(43, 7456, 120054, 300, 'mardi-13-oct.-2020', 'N° 1'),
(44, 4646, 1, 100, 'mardi-13-oct.-2020', 'N° 1'),
(45, 123, 77, 200, 'mercredi-14-oct.-2020', 'N° 1'),
(46, 5555, 12, 100, 'mercredi-14-oct.-2020', 'N° 1'),
(47, 14, 155, 100, 'mercredi-14-oct.-2020', 'N° 1'),
(48, 1234, 12, 100, 'mercredi-14-oct.-2020', 'N° 1'),
(49, 785, 12, 100, 'mercredi-14-oct.-2020', 'N° 1'),
(50, 45, 12, 200, 'mercredi-14-oct.-2020', 'N° 1'),
(51, 11, 12, 300, 'jeudi-18-févr.-2021', 'N° 1'),
(52, 1111, 12, 400, 'jeudi-18-févr.-2021', 'N° 1'),
(53, 4101, 1, 400, 'mardi-06-avr.-2021', 'N° 1'),
(54, 12587, 22, 10000, 'mardi-06-avr.-2021', 'N° 1');

--
-- Déclencheurs `payements`
--
DELIMITER $$
CREATE TRIGGER `calcul_solde` AFTER INSERT ON `payements` FOR EACH ROW UPDATE clients
SET solde = (SELECT SUM(somme) FROM payements WHERE id_client = NEW.id_client)            
WHERE clients.id_client = NEW.id_client
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_date_last_payement` AFTER INSERT ON `payements` FOR EACH ROW UPDATE dates SET dates.valeur = NEW.date_payement
WHERE dates.id = 2
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `ramassage`
--

CREATE TABLE `ramassage` (
  `id` int(11) NOT NULL,
  `id_ramassage` int(11) NOT NULL,
  `somme` double NOT NULL,
  `id_client` int(11) NOT NULL,
  `date_ramassage` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `id_user`, `username`, `password`, `type`) VALUES
(1, 1, 'beh', 'beh', 'chef'),
(2, 2, 'test', 't', 'operateur'),
(3, 3, 'raoul', 'raoul', 'cody_b');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur1`
--

CREATE TABLE `utilisateur1` (
  `id` int(11) NOT NULL,
  `id_client` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_client` (`id_client`);

--
-- Index pour la table `dates`
--
ALTER TABLE `dates`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `payements`
--
ALTER TABLE `payements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_payement` (`id_payement`),
  ADD KEY `fk_clients_payements` (`id_client`);

--
-- Index pour la table `ramassage`
--
ALTER TABLE `ramassage`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateur1`
--
ALTER TABLE `utilisateur1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_utilisateur_utilisateur1` (`id_client`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT pour la table `dates`
--
ALTER TABLE `dates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `payements`
--
ALTER TABLE `payements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pour la table `ramassage`
--
ALTER TABLE `ramassage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `utilisateur1`
--
ALTER TABLE `utilisateur1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `payements`
--
ALTER TABLE `payements`
  ADD CONSTRAINT `fk_clients_payements` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
